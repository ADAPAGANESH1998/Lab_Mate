package com.app.labmate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabmateBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
